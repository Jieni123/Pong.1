﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;

class PlayerInput
{
    MouseState currentMouseState, previousMouseState;
    KeyboardState currentKeyboardState, previousKeyboardState;
    Random Random = new Random();
    string Escape, W, S, A, D, Up, Down, Left, Right,Space;


    public void Update()
    { // escape gebruiken om uit het spel te gaan
        // het ophalen van de staat van de muis en het keyboard
        previousMouseState = currentMouseState;
        previousKeyboardState = currentKeyboardState;
        currentMouseState = Mouse.GetState();
        currentKeyboardState = Keyboard.GetState();
    }

    public bool IsKeydown(Keys )
    { return currentKeyboardState.IsKeyDown(string) && previousKeyboardState.IsKeyUp(string); }   
        

      /*  if (currentKeyboardState.IsKeyDown(Keys.Escape))
            Exit();

        //het op en neer bewegen van de blauwe & rode speler
        if (currentKeyboardState.IsKeyDown(Keys.W))
            blauweSpelerPosition.Y -= 10;
        if (currentKeyboardState.IsKeyDown(Keys.S))
            blauweSpelerPosition.Y += 10;


        if (currentKeyboardState.IsKeyDown(Keys.Up))
            rodeSpelerPosition.Y -= 10;
        if (currentKeyboardState.IsKeyDown(Keys.Down))
            rodeSpelerPosition.Y += 10;

        //door op spatie te drukken "begint" het spel weer met de bal in een random richting
        if (currentKeyboardState.IsKeyDown(Keys.Space) && !bal.balbeweegt)
        {
            bal.balbeweegt = true;
            int random = Random.Next(0, 3);
            if (random == 0)
                Game1.velocity = new Vector2(-250, -50);
            else if (random == 1)
                Game1.velocity = new Vector2(-250, 50);
            else if (random == 2)
                Game1.velocity = new Vector2(250, -50);
            else
                Game1.velocity = new Vector2(250, 50); */
        }
    }
    
}






  

    

