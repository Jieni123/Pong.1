﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pong
{
    class Bal
    {

        SpriteBatch _spriteBatch;
        Texture2D bal;
        Vector2 balPosition, balOrigin, velocity;
        Random Random = new Random();

        public Bal(ContentManager Content) // base(Content,"Bal.pixels")
        { bal = Content.Load<Texture2D>("Bal.pixels"); }

        bool balbeweegt;
    }
      
    
    public override void Playerinput(PlayerInput playerInput);
    { if (PlayerInput.IsKeyDown(Keys.Space) && !bal.balbeweegt)
        {
            bal.balbeweegt = true;
            int random = Random.Next(0, 3);
            if (random == 0)
                velocity = new Vector2(-250, -50);
            else if (random == 1)
                velocity = new Vector2(-250, 50);
            else if (random == 2)
                velocity = new Vector2(250, -50);
            else
                velocity = new Vector2(250, 50); }
}

