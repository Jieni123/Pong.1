﻿
using var game = new pong.Game1();
game.Run();
