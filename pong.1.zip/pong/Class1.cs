﻿using System;

public class Bal
{
	public Bal()
	{
	}
}
