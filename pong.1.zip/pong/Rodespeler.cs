﻿using System;

public class Rodespeler
{
	public Rodespeler()
	{
	}
}
