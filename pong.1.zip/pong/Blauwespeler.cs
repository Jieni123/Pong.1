﻿using System;

public class Blauwespeler
{
	public Blauwespeler()
	{
	}
}
