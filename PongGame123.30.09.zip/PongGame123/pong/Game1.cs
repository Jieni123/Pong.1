﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;



namespace pong
{
     public class Game1 
    {
        GraphicsDeviceManager _graphics;
        SpriteBatch _spriteBatch;
        Texture2D /*blauweSpeler, rodeSpeler,*/ background, Heart1, Heart2, bluewonscherm, redwonscherm;
        Vector2  /*blauweSpelerPosition, rodeSpelerPosition,*/ velocity, /*rodeSpelerOrigin, blauweSpelerOrigin,*/ HeartPosition1, HeartOrigin1;
        //MouseState currentMouseState, previousMouseState;
       // KeyboardState currentKeyboardState, previousKeyboardState;
        Random Random = new Random();
        int LivesPlayer1;
        int LivesPlayer2;

        //bool balbeweegt;



        // voor direction vanaf paddle https://gamedev.stackexchange.com/questions/4253/in-pong-how-do-you-calculate-the-balls-direction-when-it-bounces-off-the-paddl
        //!!! ScreenManager  https://www.syncfusion.com/succinctly-free-ebooks/monogame-succinctly/creating-the-first-game
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = false;
            LivesPlayer1 = 5;
            LivesPlayer2 = 5;
        }
        bool InGame
        { get { return LivesPlayer1 >= 0 || LivesPlayer2 >= 0; } }
        bool GameOver
        { get { return LivesPlayer1 <= 0 || LivesPlayer2 <= 0; } }
        public void LoseLifePlayer1()
        { LivesPlayer1--; }
        public void LoseLifePlayer2()
        { LivesPlayer2--; }
        protected override void Initialize()
        {
            // de grootte van het scherm
            _graphics.PreferredBackBufferWidth = 1000;
            _graphics.PreferredBackBufferHeight = 500;
            _graphics.ApplyChanges();

            base.Initialize();
        }
        protected override void LoadContent()
        {
            // het laden van de sprites
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            blauweSpeler = Content.Load<Texture2D>("blauweSpeler");
            rodeSpeler = Content.Load<Texture2D>("rodeSpeler");
            background = Content.Load<Texture2D>("background");
            Heart1 = Content.Load<Texture2D>("hartje");
            Heart2 = Content.Load<Texture2D>("hartje");
            redwonscherm = Content.Load<Texture2D>("redwonscherm");
            bluewonscherm = Content.Load<Texture2D>("bluewonscherm");

            // de origin van de sprites
            //balOrigin = new Vector2(bal.Width, bal.Height) / 2;
            rodeSpelerOrigin = new Vector2(rodeSpeler.Width, rodeSpeler.Height) / 2;
            blauweSpelerOrigin = new Vector2(blauweSpeler.Width, rodeSpeler.Height) / 2;
            HeartOrigin1 = new Vector2(500, 500);
            // HeartOrigin2 = new Vector2(500, 500);

            //de beginpositie van de sprites & de beginrichting van de velocity
           // balPosition = new Vector2(background.Width / 2, background.Height / 2);
            rodeSpelerPosition = new Vector2(background.Width - (blauweSpeler.Width / 2), background.Height / 2);
            blauweSpelerPosition = new Vector2((blauweSpeler.Width / 2), background.Height / 2);
            HeartPosition1 = new Vector2(400, 25);
            // HeartPosition2 = new Vector2(800, 25);



            /*float RandomAngle = Random.Next(0,179);
            float Angle = RandomAngle;

            float xvelocity = (float)Math.Acos(Angle)*300;
            float yvelocity = (float)Math.Asin(Angle)*300;

            velocity = new Vector2(xvelocity, yvelocity);*/

            //kiest een "random" richting
            balbeweegt = true;
            int random = Random.Next(0, 3);
            if (random == 0)
                velocity = new Vector2(-250, -50);
            else if (random == 1)
                velocity = new Vector2(-250, 50);
            else if (random == 2)
                velocity = new Vector2(250, -50);
            else
                velocity = new Vector2(250, 50);

        }

        public Rectangle balBoundingBox
        {
            get
            {
                Rectangle balspriteBounds = bal.Bounds;
                balspriteBounds.Offset(balPosition - balOrigin);
                return balspriteBounds;
            }
        }

        public Rectangle rodeSpelerBoundingBox
        {
            get
            {
                Rectangle rodeSpelerspriteBounds = rodeSpeler.Bounds;
                rodeSpelerspriteBounds.Offset(rodeSpelerPosition - rodeSpelerOrigin);
                return rodeSpelerspriteBounds;
            }
        }
        public Rectangle blauweSpelerBoundingBox
        {
            get
            {
                Rectangle blauweSpelerspriteBounds = blauweSpeler.Bounds;
                blauweSpelerspriteBounds.Offset(blauweSpelerPosition - blauweSpelerOrigin);
                return blauweSpelerspriteBounds;
            }
        }

        public void balReset()
        {
            balPosition = new Vector2(background.Width / 2, background.Height / 2);
            velocity = Vector2.Zero;
            balbeweegt = false;
        }

      /*  public void PlayerInput()
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            // het ophalen van de staat van de muis en het keyboard
            previousMouseState = currentMouseState;
            previousKeyboardState = currentKeyboardState;
            currentMouseState = Mouse.GetState();
            currentKeyboardState = Keyboard.GetState();

            // escape gebruiken om uit het spel te gaan
            if (currentKeyboardState.IsKeyDown(Keys.Escape))
                Exit();

            //het op en neer bewegen van de blauwe & rode speler
            if (currentKeyboardState.IsKeyDown(Keys.W))
                blauweSpelerPosition.Y -= 10;
            if (currentKeyboardState.IsKeyDown(Keys.S))
                blauweSpelerPosition.Y += 10;


            if (currentKeyboardState.IsKeyDown(Keys.Up))
                rodeSpelerPosition.Y -= 10;
            if (currentKeyboardState.IsKeyDown(Keys.Down))
                rodeSpelerPosition.Y += 10;

            //door op spatie te drukken "begint" het spel weer met de bal in een random richting
            if (currentKeyboardState.IsKeyDown(Keys.Space) && !balbeweegt)
            {
                balbeweegt = true;
                int random = Random.Next(0, 3);
                if (random == 0)
                    velocity = new Vector2(-250, -50);
                else if (random == 1)
                    velocity = new Vector2(-250, 50);
                else if (random == 2)
                    velocity = new Vector2(250, -50);
                else
                    velocity = new Vector2(250, 50);
            }
            //  if (currentKeyboardState.IsKeyDown(Keys.Enter))
            //   LoseLife();
        }*/

        protected override void Update(GameTime gameTime)
        {
            PlayerInput();

            //het bewegen van de bal    
            balPosition += velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;

            //voorkomen dat de blauwe en rode speler van het scherm afgaan
            if (blauweSpelerPosition.Y > (500 - (blauweSpeler.Height / 2)))
                blauweSpelerPosition.Y = (500 - (blauweSpeler.Height / 2));
            if (blauweSpelerPosition.Y < (blauweSpeler.Height / 2))
                blauweSpelerPosition.Y = (blauweSpeler.Height / 2);

            if (rodeSpelerPosition.Y > (500 - (rodeSpeler.Height / 2)))
                rodeSpelerPosition.Y = (500 - (rodeSpeler.Height / 2));
            if (rodeSpelerPosition.Y < (rodeSpeler.Height / 2))
                rodeSpelerPosition.Y = (rodeSpeler.Height / 2);

            //het bouncen van de bal tegen de boven en onderkant
            if (balPosition.Y <= 0)
                velocity.Y *= -1;
            if (balPosition.Y >= 500)
                velocity.Y *= -1;
            //bal gaat terug naar het begin als hij tegen de zijkanten aankomt
            if (balPosition.X <= 0)
                LoseLifePlayer1();
            if (balPosition.X <= 0)
                balReset();
            if (balPosition.X >= 1000)
                LoseLifePlayer2();
            if (balPosition.X >= 1000)
                balReset();


            //bal bouncet terug en versnelt als hij een speler raakt

            if (balBoundingBox.Intersects(rodeSpelerBoundingBox))
            {
                velocity.X *= -1;
                if (velocity.X > 0)
                    velocity.X += 30;
                else
                    velocity.X -= 30;
                if (velocity.Y > 0)
                    velocity.Y += 30;
                else
                    velocity.Y -= 30; }

            if (balBoundingBox.Intersects(blauweSpelerBoundingBox))
            { velocity.X *= -1;
                if (velocity.X > 0)
                    velocity.X += 30;
                else
                    velocity.X -= 30;
                if (velocity.Y > 0)
                    velocity.Y += 30;
                else
                    velocity.Y -= 30; }
            base.Update(gameTime);
        }
       /*  void GameReset()
         {
             lives = 5;
             Heart1.GameReset(); 
             Heart2.GameReset();
             bal.GameReset();
             rodeSpelerPosition.Reset();
             blauweSpelerPosition.Reset();
             
         }*/
        
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.LightSkyBlue);
            _spriteBatch.Begin();
            _spriteBatch.Draw(background, Vector2.Zero, Color.White);
            
            _spriteBatch.Draw(background, Vector2.Zero, Color.White);
            _spriteBatch.Draw(bal, balPosition - balOrigin, Color.White);
            _spriteBatch.Draw(blauweSpeler, blauweSpelerPosition - blauweSpelerOrigin, Color.White);
            _spriteBatch.Draw(rodeSpeler, rodeSpelerPosition - rodeSpelerOrigin, Color.White);

            //telkens als de bal bij de y as komt zal er 1 hartje weggaan
            for (int Die1 = 0; Die1 < LivesPlayer1; Die1++)
            { _spriteBatch.Draw(Heart1, new Vector2(Die1 * Heart1.Width + 50, 0), Color.White); }
            for (int Die2 = 0; Die2 < LivesPlayer2; Die2++)
            { _spriteBatch.Draw(Heart2, new Vector2(Die2 * Heart2.Width + (background.Width - 100), 0), Color.White); }

            //GameOver scherm komt naar boven wanneer de levens 0 zijn https://www.youtube.com/watch?v=76Mz7ClJLoE 
            if (GameOver)
            {
                GraphicsDevice.Clear(Color.White);

                if (LivesPlayer1 == 0)
                    _spriteBatch.Draw(redwonscherm, Vector2.Zero, Color.White);
                else
                    _spriteBatch.Draw(bluewonscherm, Vector2.Zero, Color.White);
            }
        
           /* else if (PlayerInput.currentKeyboardState(Keys.R)
                GameReset();*/
 
            _spriteBatch.End();

            base.Draw(gameTime);
            // class for bal, blauwespeler, game1, playerinput, program, rodespeler
        }
    }
}