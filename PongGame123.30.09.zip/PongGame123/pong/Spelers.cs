﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pong
{
    public class Spelers : Game1
    {
        GraphicsDeviceManager _graphics;
        SpriteBatch _spriteBatch;
        Texture2D rodeSpeler, blauweSpeler;
         
        PlayerInput playerInput;
        

        static Game1 game1;

        public static Game1 Game1;
       { get { return game1; } }

public static Random Random { get; private set; }

protected override void LoadContent()
{
    spriteBatch = new SpriteBatch(GraphicsDevice);
    blauweSpeler = Content.Load<Texture2D>("blauweSpeler");
    rodeSpeler = Content.Load<Texture2D>("rodeSpeler");
}
    }
}
